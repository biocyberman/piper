package ncsa.hdf.hdf5lib.callbacks;

public interface H5L_iterate_t {
/**    public ArrayList iterdata = new ArrayList();
  * Any derived interfaces must define the single public varaible as above.
  */
}
