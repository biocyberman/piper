/*
 * Copyright 2007 - 2014 ETH Zuerich, CISD and SIS.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package ch.systemsx.cisd.hdf5.cleanup;

/**
 * A role that calls a method which requires one or more clean-up steps that need to be run reliably
 * at the end of the method regardless of whether the method is finished normally or whether it
 * exits with an exception.
 * <p>
 * <em>This is an internal interface that is not meant to be used by users of the library.</em>
 * 
 * @author Bernd Rinn
 */
public interface ICallableWithCleanUp<T>
{

    /** Calls the method requiring clean-up. */
    public T call(ICleanUpRegistry registry);

}
